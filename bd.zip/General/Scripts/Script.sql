ALTER SEQUENCE home_categoria_id_seq RESTART WITH 1;
